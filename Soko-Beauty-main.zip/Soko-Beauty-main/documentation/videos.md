# Videos Documention

This will document how **videos** are working on soko

## watch videos screen

- change to curpertino icons
- added