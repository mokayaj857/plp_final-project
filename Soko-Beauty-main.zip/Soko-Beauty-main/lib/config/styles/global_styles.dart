
class AppSizes {
  static const double drawerWidth = 250.0;
  static const double bottomAppBarHeight = 56.0;
}
