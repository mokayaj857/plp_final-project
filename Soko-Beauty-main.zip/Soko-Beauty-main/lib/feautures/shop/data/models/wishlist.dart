class Wishlist {
  List<String> itemIds;

  Wishlist({required this.itemIds});
}
