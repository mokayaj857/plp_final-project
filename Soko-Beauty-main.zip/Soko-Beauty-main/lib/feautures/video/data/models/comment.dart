class Comment {
  String userId;
  String text;
  DateTime timestamp;
  Comment({required this.userId, required this.text, required this.timestamp});
}
