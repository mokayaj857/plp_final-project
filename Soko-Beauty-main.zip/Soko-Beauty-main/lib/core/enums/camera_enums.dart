enum CameraErrorType { permission, other }
